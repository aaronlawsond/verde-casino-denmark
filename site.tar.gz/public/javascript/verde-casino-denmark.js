'use strict';

const navigationButton = document.querySelector('[data-navigation-toggle]');
const navigationPanel = document.querySelector('[data-navigation-panel]');
const languageButton = document.querySelector('[data-language-toggle]');
const languagePanel = document.querySelector('[data-language-panel]');

function setNavigation(open, restoreFocus = false) {
  if (!navigationButton || !navigationPanel) return;
  navigationButton.setAttribute('aria-expanded', String(open));
  navigationPanel.classList.toggle('is-open', open);
  if (!open) setLanguages(false);
  if (restoreFocus) navigationButton.focus();
}

function setLanguages(open, restoreFocus = false) {
  if (!languageButton || !languagePanel) return;
  languageButton.setAttribute('aria-expanded', String(open));
  languagePanel.hidden = !open;
  if (restoreFocus) languageButton.focus();
}

navigationButton?.addEventListener('click', () => {
  setNavigation(navigationButton.getAttribute('aria-expanded') !== 'true');
});
languageButton?.addEventListener('click', () => {
  setLanguages(languageButton.getAttribute('aria-expanded') !== 'true');
});

document.addEventListener('keydown', event => {
  if (event.key !== 'Escape') return;
  if (languageButton?.getAttribute('aria-expanded') === 'true') {
    setLanguages(false, true);
  } else if (navigationButton?.getAttribute('aria-expanded') === 'true') {
    setNavigation(false, true);
  }
});

document.addEventListener('click', event => {
  if (languagePanel && !event.target.closest('[data-language-picker]')) setLanguages(false);
  if (navigationPanel && !event.target.closest('header')) setNavigation(false);
});

navigationPanel?.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => setNavigation(false));
});

const desktopNavigation = matchMedia('(min-width: 1051px)');
desktopNavigation.addEventListener('change', () => setNavigation(false));

document.querySelectorAll('[data-language-link]').forEach(link => {
  const equivalent = new URL(link.href, location.href);
  equivalent.search = location.search;
  equivalent.hash = location.hash;
  link.href = equivalent.href;
});

document.querySelectorAll('[data-faq-question]').forEach(button => {
  button.setAttribute('aria-expanded', 'false');
  document.getElementById(button.getAttribute('aria-controls')).hidden = true;
  button.addEventListener('click', () => {
    const shouldOpen = button.getAttribute('aria-expanded') !== 'true';
    document.querySelectorAll('[data-faq-question]').forEach(other => {
      const answer = document.getElementById(other.getAttribute('aria-controls'));
      const open = other === button && shouldOpen;
      other.setAttribute('aria-expanded', String(open));
      if (answer) answer.hidden = !open;
    });
  });
});
